using System.Xml.Linq;

namespace tlotdREMAKEEEEEEE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            btnStartGame.Click += ButtonActionTitle;
            this.Load += TitleScreen;
        }

        public void TitleScreen(object sender, EventArgs e)
        {
            pbMain.Image = tlotdREMAKEEEEEEE.Properties.Resources.title;
        }

        public void ButtonActionTitle(object sender, EventArgs e)
        {
            //jatekmegnyitasa
            pbMain.Image = null;
            pbMain.Invalidate();
            pbMain.Image = tlotdREMAKEEEEEEE.Properties.Resources.town;
            btnCave.Visible = true;
            btnShop.Visible = true;
        }
    }
}
