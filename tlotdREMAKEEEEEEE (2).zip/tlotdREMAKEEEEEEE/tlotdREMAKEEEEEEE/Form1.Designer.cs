﻿namespace tlotdREMAKEEEEEEE
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnStartGame = new Button();
            pbMain = new PictureBox();
            btnShop = new Button();
            btnCave = new Button();
            ((System.ComponentModel.ISupportInitialize)pbMain).BeginInit();
            SuspendLayout();
            // 
            // btnStartGame
            // 
            btnStartGame.Location = new Point(405, 530);
            btnStartGame.Name = "btnStartGame";
            btnStartGame.Size = new Size(388, 64);
            btnStartGame.TabIndex = 0;
            btnStartGame.Text = "Press &A to continue";
            btnStartGame.UseVisualStyleBackColor = true;
            // 
            // pbMain
            // 
            pbMain.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pbMain.BackgroundImageLayout = ImageLayout.Center;
            pbMain.Cursor = Cursors.No;
            pbMain.Location = new Point(214, 24);
            pbMain.Name = "pbMain";
            pbMain.Size = new Size(736, 500);
            pbMain.SizeMode = PictureBoxSizeMode.CenterImage;
            pbMain.TabIndex = 1;
            pbMain.TabStop = false;
            // 
            // btnShop
            // 
            btnShop.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            btnShop.BackColor = SystemColors.ButtonHighlight;
            btnShop.FlatStyle = FlatStyle.Popup;
            btnShop.Location = new Point(363, 437);
            btnShop.Name = "btnShop";
            btnShop.Size = new Size(102, 34);
            btnShop.TabIndex = 2;
            btnShop.Text = "Shop";
            btnShop.UseVisualStyleBackColor = false;
            btnShop.Visible = false;
            // 
            // btnCave
            // 
            btnCave.BackColor = SystemColors.ButtonHighlight;
            btnCave.FlatStyle = FlatStyle.Popup;
            btnCave.ForeColor = SystemColors.ActiveCaptionText;
            btnCave.Location = new Point(707, 437);
            btnCave.Name = "btnCave";
            btnCave.Size = new Size(102, 34);
            btnCave.TabIndex = 3;
            btnCave.Text = "Cave";
            btnCave.TextImageRelation = TextImageRelation.ImageAboveText;
            btnCave.UseVisualStyleBackColor = false;
            btnCave.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1294, 606);
            Controls.Add(btnCave);
            Controls.Add(btnShop);
            Controls.Add(pbMain);
            Controls.Add(btnStartGame);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pbMain).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnStartGame;
        private PictureBox pbMain;
        private Button btnShop;
        private Button btnCave;
    }
}
